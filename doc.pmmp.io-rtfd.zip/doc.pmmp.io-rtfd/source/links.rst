Useful Links
------------

.. _links:

* `PMMP GitHub organisation <https://www.github.com/pmmp/>`_
* `PocketMine-MP GitHub repository <https://github.com/pmmp/pocketmine-mp>`_
* `PHP compile scripts <https://github.com/pmmp/php-build-scripts>`_
* `Linux & MacOS install script source <https://github.com/pmmp/php-build-scripts/blob/stable/installer.sh>`_
* `PMMP Website <https://pmmp.io/>`_
* `PMMP Forums <https://forums.pmmp.io>`_
* `PocketMine-MP Translation Project <http://translate.pocketmine.net/>`_
