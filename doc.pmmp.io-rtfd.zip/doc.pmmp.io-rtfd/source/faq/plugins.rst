Plugins
~~~~~~~

.. toctree::
    :glob:

    plugins/*
