Can I install PocketMine-MP on Windows XP?
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

PocketMine-MP can not be installed on Windows XP.
Is it an old computer? Try Linux!
