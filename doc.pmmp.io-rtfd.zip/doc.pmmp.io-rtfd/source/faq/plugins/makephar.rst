I can't get a ``.phar`` for a plugin. How do I create one?
""""""""""""""""""""""""""""""""""""""""""""""""""""""""""

You can create ``.phar`` files from plugin source code using the `DevTools`_ plugin. Instructions on how to build a phar from source code are given on the README.md.

.. _DevTools: https://github.com/pmmp/PocketMine-DevTools