Can I run a plugin from source without creating a ``.phar``?
""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""

You can use the `DevTools`_ plugin to load source plugins (known as "folder plugins").

.. warning::
	It is discouraged to use either DevTools or folder plugins on a production server.

For small test plugins there is a new way, check out `this forum thread <forumthread_>`_

.. _DevTools: https://github.com/pmmp/PocketMine-DevTools
.. _forumthread: https://forums.pocketmine.net/threads/new-plugin-scripting-format-draft.8335/
