Playing
~~~~~~~

.. toctree::
    :glob:

    playing/*
