.. _shoghicp:

Who is @shoghicp?
~~~~~~~~~~~~~~~~~

`@shoghicp (Shoghi Cervantes) <https://github.com/shoghicp>`_ is the creator of PocketMine-MP (originally Pocket Minecraft PHP).

Shoghi developed the project from October 2012 until January 2016. He was `hired by Mojang to work on Minecraft PE <https://forums.pocketmine.net/threads/im-working-at-mojang.6829/>`_ in 2014.

He was forced to stop developing PocketMine-MP due to conflicts with his job developing Minecraft PE at Mojang.

