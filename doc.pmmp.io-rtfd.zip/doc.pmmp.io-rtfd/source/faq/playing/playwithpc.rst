Can Minecraft: Java Edition (PC) clients connect to a PocketMine-MP server?
"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""

No, but plugins exist which add partial support for this. Look up "BigBrother" on GitHub.
