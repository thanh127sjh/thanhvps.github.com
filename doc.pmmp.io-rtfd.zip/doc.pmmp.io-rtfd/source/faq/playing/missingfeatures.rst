Why doesn't X or Y gameplay feature work on PocketMine-MP? Is it a bug?
"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""

PocketMine-MP does not have all gameplay features that Minecraft itself offers. This is because PocketMine-MP is developed by developers in their spare time who have difficulty keeping up with new Minecraft features.

Most notably, current missing features at the time of writing include mobs, redstone, minecarts and dimensions. These will be added in the future.
