Unable to build without OP permissions
""""""""""""""""""""""""""""""""""""""

This is usually caused by the built-in spawn protection. By default it protects a circle of radius 16 blocks around the spawn point.
Try moving more than 16 blocks from the spawn and see if you're able to build.

You can disable or configure the spawn protection using the ``spawn-protection`` setting in your ``server.properties``. Set it to ``-1`` to turn it off.