Can other users connect to my server?
"""""""""""""""""""""""""""""""""""""

Users on the same network are able to join the server.
If you want other people from outside your own network to be able to join then you need to port-forward.
