How do I add an external server which is not on my network?
"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
To connect to a server by IP/address and port, you need to add it to the Servers list.


.. image:: /img/add-server-1.png
.. image:: /img/add-server-2.png
.. image:: /img/add-server-3.png

.. note::
    A local server should show up on the ``Friends`` tab without adding the details.
