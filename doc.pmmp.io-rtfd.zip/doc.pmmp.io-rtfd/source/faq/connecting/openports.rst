Do I have to open ports in my firewall?
"""""""""""""""""""""""""""""""""""""""

If you have a firewall set up then you need to allow access to ``UDP port 19132``.

.. note::
    Do you want to use **RCON**? If so, then ``TCP port 19132`` also needs to be open.

.. note::
	On Windows, you might get a dialog like this when you first start the server. Click "Allow access" to allow PocketMine-MP through the firewall and allow players to connect.

	.. image:: /img/windows-firewall.png
