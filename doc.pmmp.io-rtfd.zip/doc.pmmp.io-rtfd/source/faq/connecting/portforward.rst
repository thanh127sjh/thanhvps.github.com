Do I have to configure port forwarding?
"""""""""""""""""""""""""""""""""""""""

This is only needed when you want people from outside your network to connect.
Check `portforward.com`_ or use `Google`_ to find the instructions. Use the brand and type of your router as keywords.

.. note::
    * UDP port: 19132 for PocketMine-MP and Query
    * TCP port: 19132 for RCON

.. _portforward.com: http://portforward.com/english/routers/port_forwarding/routerindex.htm
.. _Google: https://www.google.com
