.. _plugin_formats:

Plugin formats
++++++++++++++

PocketMine-MP supports several plugin formats. The standard ones are described below; you can make your own by making a custom plugin loader.

.. toctree::
    :maxdepth: 2

    plugin-formats/standard
    plugin-formats/development
    plugin-formats/faq
