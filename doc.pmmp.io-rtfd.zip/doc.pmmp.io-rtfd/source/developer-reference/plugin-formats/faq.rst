.. _plugin_formats_faq:

Frequently Asked Questions
~~~~~~~~~~~~~~~~~~~~~~~~~~

Does the ``/reload`` command reload plugin source code?
-------------------------------------------------------

No. This is not currently possible.

How do I load a ``.zip`` plugin?
--------------------------------

PocketMine-MP does not directly support loading zip plugins, but there may be third-party plugins available which allow you to do this. However, this is not recommended.
